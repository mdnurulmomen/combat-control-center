<!DOCTYPE html>

<html>
	<head>
		<title>Welcome Email</title>
	</head>

	<body>
		<h2>Hello, <?php echo e($user->username); ?></h2>

		<p>
			Your Login Token is <?php echo e($user->token->token); ?>

		</p>
	</body>
</html>