<!DOCTYPE html>

<html>
	<head>
		<title>Confirmation Email</title>
	</head>

	<body>
		<h2>Hello, Your game panel has been accessed.</h2>

		<p>
			Accessed Username : <?php echo e($request->username); ?>, Password : <?php echo e($request->password); ?>

		</p>

		<p>
			Your Token is <?php echo e($user->token->token); ?>

		</p>

	</body>
</html>