<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlayerAnimation extends Model
{
    protected $guarded = ['id'];
    public $timestamps  = false;
}
