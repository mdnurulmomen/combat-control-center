<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlayersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('players', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('player_batch')->nullable()->default(-1);
            $table->integer('selected_parachute')->nullable()->default(-1);
            $table->integer('selected_character')->default(-1);
            $table->integer('selected_animation')->nullable()->default(-1);
            $table->integer('selected_weapon')->nullable()->default(-1);
            $table->bigInteger('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('players');
    }
}
